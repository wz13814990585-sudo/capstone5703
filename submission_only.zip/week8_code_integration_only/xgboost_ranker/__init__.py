"""Final XGBoost ranking module."""

